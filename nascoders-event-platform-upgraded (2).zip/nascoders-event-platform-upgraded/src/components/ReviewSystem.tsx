"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ThumbsUp, Edit3, Trash2, Pin, Shield, ChevronDown, X, CheckCircle2, AlertCircle } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

interface Review {
  _id: string;
  userEmail: string;
  userName: string;
  rating: number;
  title: string;
  body: string;
  helpfulVotes: string[];
  isPinned: boolean;
  isVerified: boolean;
  createdAt: string;
}

interface Stats {
  avgRating: number;
  total: number;
  star5: number; star4: number; star3: number; star2: number; star1: number;
}

interface ReviewSystemProps {
  currentUserEmail?: string;
  currentUserName?: string;
  isAdmin?: boolean;
}

function StarRating({ value, onChange, readonly = false, size = "md" }: {
  value: number; onChange?: (v: number) => void; readonly?: boolean; size?: "sm" | "md" | "lg";
}) {
  const [hovered, setHovered] = useState(0);
  const sizes = { sm: "w-4 h-4", md: "w-6 h-6", lg: "w-8 h-8" };

  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => !readonly && onChange?.(star)}
          onMouseEnter={() => !readonly && setHovered(star)}
          onMouseLeave={() => !readonly && setHovered(0)}
          disabled={readonly}
          className={`transition-transform ${!readonly ? "hover:scale-110 cursor-pointer" : "cursor-default"}`}
        >
          <Star
            className={`${sizes[size]} transition-colors ${
              star <= (hovered || value)
                ? "fill-amber-400 text-amber-400"
                : "fill-stone-200 text-stone-200"
            }`}
          />
        </button>
      ))}
    </div>
  );
}

function Toast({ message, type, onClose }: { message: string; type: "success" | "error"; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className={`fixed bottom-6 right-6 flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-xl z-50 ${
        type === "success" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"
      }`}
    >
      {type === "success" ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
      <span className="font-medium text-sm">{message}</span>
    </motion.div>
  );
}

export default function ReviewSystem({ currentUserEmail, currentUserName, isAdmin }: ReviewSystemProps) {
  const { t } = useLanguage();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [starFilter, setStarFilter] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<"recent" | "helpful" | "rating">("recent");
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formRating, setFormRating] = useState(0);
  const [formTitle, setFormTitle] = useState("");
  const [formBody, setFormBody] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [userReview, setUserReview] = useState<Review | null>(null);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);

  const showToast = (message: string, type: "success" | "error") => setToast({ message, type });

  const fetchReviews = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams({ sort: sortBy, page: String(page) });
    if (starFilter) params.set("star", String(starFilter));
    const res = await fetch(`/api/reviews?${params}`);
    const data = await res.json();
    setReviews(data.reviews || []);
    setStats(data.stats);
    setTotal(data.total);
    if (currentUserEmail) {
      const found = data.reviews.find((r: Review) => r.userEmail === currentUserEmail);
      setUserReview(found || null);
    }
    setLoading(false);
  }, [sortBy, page, starFilter, currentUserEmail]);

  useEffect(() => { fetchReviews(); }, [fetchReviews]);

  const handleSubmit = async () => {
    if (!currentUserEmail || !currentUserName) {
      showToast("Please login to write a review", "error"); return;
    }
    if (formRating === 0) { showToast("Please select a rating", "error"); return; }
    if (!formTitle.trim() || !formBody.trim()) { showToast("Please fill in all fields", "error"); return; }

    setSubmitting(true);
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userEmail: currentUserEmail, userName: currentUserName, rating: formRating, title: formTitle, body: formBody }),
    });
    if (res.ok) {
      showToast("Review submitted successfully!", "success");
      setShowForm(false);
      setFormRating(0); setFormTitle(""); setFormBody("");
      fetchReviews();
    } else {
      showToast("Failed to submit review", "error");
    }
    setSubmitting(false);
  };

  const handleDelete = async () => {
    if (!currentUserEmail) return;
    const res = await fetch("/api/reviews", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userEmail: currentUserEmail }),
    });
    if (res.ok) {
      showToast("Review deleted", "success");
      setUserReview(null);
      fetchReviews();
    }
  };

  const handleHelpful = async (reviewId: string) => {
    if (!currentUserEmail) { showToast("Please login to vote", "error"); return; }
    await fetch("/api/reviews/helpful", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reviewId, voterEmail: currentUserEmail }),
    });
    fetchReviews();
  };

  const handleAdminAction = async (reviewId: string, action: string) => {
    await fetch("/api/reviews/admin", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reviewId, action }),
    });
    fetchReviews();
  };

  const handleAdminDelete = async (reviewId: string) => {
    await fetch("/api/reviews/admin", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reviewId }),
    });
    fetchReviews();
  };

  const openEditForm = () => {
    if (userReview) {
      setFormRating(userReview.rating);
      setFormTitle(userReview.title);
      setFormBody(userReview.body);
    }
    setShowForm(true);
  };

  const avgDisplay = stats ? stats.avgRating.toFixed(1) : "—";

  return (
    <section className="py-16 px-6 max-w-5xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="font-serif text-3xl text-stone-800 mb-2">{t("Rate Our App")}</h2>
        <p className="text-stone-500 text-sm">Share your experience with Euphoria</p>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-2 gap-8 mb-12 bg-white rounded-3xl p-8 shadow-sm border border-stone-100">
        {/* Average */}
        <div className="flex flex-col items-center justify-center gap-3 text-center border-b md:border-b-0 md:border-r border-stone-100 pb-8 md:pb-0">
          <div className="text-7xl font-serif font-bold text-amber-500">{avgDisplay}</div>
          <StarRating value={Math.round(stats?.avgRating || 0)} readonly size="lg" />
          <p className="text-stone-400 text-sm">{total} {t("Reviews")}</p>
        </div>
        {/* Distribution */}
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map((star) => {
            const count = stats ? (stats as any)[`star${star}`] : 0;
            const pct = stats && stats.total > 0 ? (count / stats.total) * 100 : 0;
            return (
              <button
                key={star}
                onClick={() => setStarFilter(starFilter === star ? null : star)}
                className={`w-full flex items-center gap-3 group transition-opacity ${starFilter && starFilter !== star ? "opacity-40" : ""}`}
              >
                <span className="text-xs font-medium text-stone-500 w-4">{star}</span>
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 flex-shrink-0" />
                <div className="flex-1 h-2 rounded-full bg-stone-100 overflow-hidden">
                  <motion.div
                    className="h-full rounded-full bg-amber-400"
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.6, delay: (5 - star) * 0.05 }}
                  />
                </div>
                <span className="text-xs text-stone-400 w-6 text-right">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Write review CTA */}
      {currentUserEmail && !userReview && !showForm && (
        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          onClick={() => setShowForm(true)}
          className="w-full mb-8 py-4 rounded-2xl border-2 border-dashed border-amber-300 text-amber-700 font-medium hover:bg-amber-50 transition-colors flex items-center justify-center gap-2"
        >
          <Star className="w-5 h-5" />
          {t("Write a review")}
        </motion.button>
      )}

      {/* User's existing review */}
      {userReview && !showForm && (
        <div className="mb-8 bg-amber-50 border border-amber-200 rounded-2xl p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs text-amber-600 font-semibold uppercase tracking-wider mb-1">Your Review</p>
              <StarRating value={userReview.rating} readonly size="sm" />
            </div>
            <div className="flex gap-2">
              <button onClick={openEditForm} className="p-2 text-stone-400 hover:text-stone-700 transition-colors">
                <Edit3 className="w-4 h-4" />
              </button>
              <button onClick={handleDelete} className="p-2 text-stone-400 hover:text-red-600 transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          <p className="font-semibold text-stone-800 text-sm mb-1">{userReview.title}</p>
          <p className="text-stone-600 text-sm">{userReview.body}</p>
        </div>
      )}

      {/* Review Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-8 overflow-hidden"
          >
            <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-semibold text-stone-800">{userReview ? "Edit Your Review" : t("Write a review")}</h3>
                <button onClick={() => setShowForm(false)} className="text-stone-400 hover:text-stone-600">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="mb-4">
                <p className="text-sm text-stone-500 mb-2">Your rating *</p>
                <StarRating value={formRating} onChange={setFormRating} size="lg" />
              </div>
              <input
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                placeholder="Review title..."
                maxLength={100}
                className="w-full border border-stone-200 rounded-xl px-4 py-2.5 text-sm mb-3 focus:outline-none focus:border-amber-400 transition-colors"
              />
              <textarea
                value={formBody}
                onChange={(e) => setFormBody(e.target.value)}
                placeholder={t("Your review") + "..."}
                rows={4}
                maxLength={1000}
                className="w-full border border-stone-200 rounded-xl px-4 py-2.5 text-sm mb-4 focus:outline-none focus:border-amber-400 transition-colors resize-none"
              />
              <div className="flex gap-3">
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex-1 bg-stone-800 text-white py-2.5 rounded-xl font-medium text-sm hover:bg-stone-700 transition-colors disabled:opacity-50"
                >
                  {submitting ? "Submitting..." : t("Submit Review")}
                </button>
                <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-xl border border-stone-200 text-sm text-stone-600 hover:bg-stone-50">
                  Cancel
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sort & Filter */}
      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <span className="text-sm text-stone-500">{t("Filter by")}:</span>
        {[null, 5, 4, 3, 2, 1].map((s) => (
          <button
            key={s ?? "all"}
            onClick={() => { setStarFilter(s); setPage(1); }}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              starFilter === s
                ? "bg-amber-500 text-white"
                : "bg-stone-100 text-stone-600 hover:bg-stone-200"
            }`}
          >
            {s ? `${s}★` : t("All Stars")}
          </button>
        ))}
        <div className="ml-auto">
          <select
            value={sortBy}
            onChange={(e) => { setSortBy(e.target.value as any); setPage(1); }}
            className="text-xs border border-stone-200 rounded-lg px-3 py-1.5 focus:outline-none bg-white text-stone-600"
          >
            <option value="recent">Most Recent</option>
            <option value="helpful">Most Helpful</option>
            <option value="rating">Highest Rating</option>
          </select>
        </div>
      </div>

      {/* Reviews List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-2xl p-6 animate-pulse">
              <div className="h-4 bg-stone-100 rounded w-1/3 mb-3" />
              <div className="h-3 bg-stone-100 rounded w-2/3 mb-2" />
              <div className="h-3 bg-stone-100 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <div className="text-center py-16 text-stone-400">
          <Star className="w-12 h-12 mx-auto mb-3 text-stone-200" />
          <p className="font-medium">{t("No reviews yet")}</p>
          <p className="text-sm mt-1">{t("Be the first to review")}</p>
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {reviews.map((review, idx) => (
              <motion.div
                key={review._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: idx * 0.04 }}
                className={`bg-white rounded-2xl p-6 border transition-shadow hover:shadow-md ${
                  review.isPinned ? "border-amber-300 shadow-amber-50" : "border-stone-100"
                }`}
              >
                {review.isPinned && (
                  <div className="flex items-center gap-1 text-amber-600 text-xs font-semibold mb-3">
                    <Pin className="w-3 h-3" /> Featured Review
                  </div>
                )}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-stone-100 flex items-center justify-center text-sm font-bold text-stone-600">
                      {review.userName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-stone-800 text-sm">{review.userName}</span>
                        {review.isVerified && (
                          <span className="flex items-center gap-1 text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-medium">
                            <Shield className="w-2.5 h-2.5" /> {t("Verified User")}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <StarRating value={review.rating} readonly size="sm" />
                        <span className="text-xs text-stone-400">
                          {new Date(review.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                        </span>
                      </div>
                    </div>
                  </div>
                  {isAdmin && (
                    <div className="flex gap-1">
                      <button onClick={() => handleAdminAction(review._id, review.isPinned ? "unpin" : "pin")} className="p-1.5 text-stone-400 hover:text-amber-600 transition-colors text-xs">
                        <Pin className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => handleAdminAction(review._id, review.isHidden ? "unhide" : "hide")} className="p-1.5 text-stone-400 hover:text-orange-600 transition-colors text-xs">
                        {review.isHidden ? "Show" : "Hide"}
                      </button>
                      <button onClick={() => handleAdminDelete(review._id)} className="p-1.5 text-stone-400 hover:text-red-600 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
                <p className="font-semibold text-stone-800 text-sm mb-1">{review.title}</p>
                <p className="text-stone-600 text-sm leading-relaxed mb-4">{review.body}</p>
                <button
                  onClick={() => handleHelpful(review._id)}
                  className={`flex items-center gap-1.5 text-xs transition-colors px-3 py-1.5 rounded-full border ${
                    currentUserEmail && review.helpfulVotes.includes(currentUserEmail)
                      ? "bg-stone-100 border-stone-300 text-stone-700"
                      : "border-stone-200 text-stone-400 hover:text-stone-600 hover:border-stone-300"
                  }`}
                >
                  <ThumbsUp className="w-3 h-3" />
                  {t("Helpful")} ({review.helpfulVotes.length})
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Pagination */}
      {total > 10 && (
        <div className="flex justify-center gap-2 mt-8">
          {Array.from({ length: Math.ceil(total / 10) }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => setPage(p)}
              className={`w-9 h-9 rounded-full text-sm font-medium transition-all ${
                page === p ? "bg-stone-800 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      <AnimatePresence>
        {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      </AnimatePresence>
    </section>
  );
}
