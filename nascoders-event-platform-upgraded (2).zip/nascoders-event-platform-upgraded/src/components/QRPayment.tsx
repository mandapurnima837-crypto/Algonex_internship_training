"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, CheckCircle2, AlertCircle, Clock, Download, RefreshCw, 
  Smartphone, Copy, ChevronRight, Loader2
} from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

interface PaymentData {
  orderId: string;
  upiString: string;
  upiId: string;
  amount: number;
  qrExpiry: string;
}

interface QRPaymentProps {
  amount: number;
  occasion: string;
  userEmail: string;
  userName: string;
  onSuccess?: (orderId: string) => void;
  onClose?: () => void;
}

type PaymentStep = "init" | "qr" | "confirming" | "success" | "failed" | "expired";

const UPI_APPS = [
  { name: "Google Pay", icon: "🟢", scheme: "gpay" },
  { name: "PhonePe",    icon: "🟣", scheme: "phonepe" },
  { name: "Paytm",      icon: "🔵", scheme: "paytm" },
  { name: "BHIM",       icon: "🟠", scheme: "bhim" },
];

// Minimal canvas-based QR generator
function generateQRDataURL(text: string): string {
  // We use a canvas element to render a placeholder styled QR.
  // In production, use 'qrcode' npm package.
  return `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(text)}&bgcolor=FFFAF0&color=1C1917&margin=10`;
}

function CountdownTimer({ expiry, onExpired }: { expiry: string; onExpired: () => void }) {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const tick = () => {
      const diff = Math.max(0, Math.floor((new Date(expiry).getTime() - Date.now()) / 1000));
      setTimeLeft(diff);
      if (diff === 0) onExpired();
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiry, onExpired]);

  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  const pct = Math.min(100, (timeLeft / 600) * 100); // 10 min max

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-16 h-16">
        <svg className="w-16 h-16 -rotate-90" viewBox="0 0 56 56">
          <circle cx="28" cy="28" r="24" fill="none" stroke="#e7e5e4" strokeWidth="4" />
          <circle
            cx="28" cy="28" r="24" fill="none"
            stroke={timeLeft < 60 ? "#ef4444" : "#f59e0b"}
            strokeWidth="4"
            strokeDasharray={`${2 * Math.PI * 24}`}
            strokeDashoffset={`${2 * Math.PI * 24 * (1 - pct / 100)}`}
            className="transition-all duration-1000"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`text-xs font-bold tabular-nums ${timeLeft < 60 ? "text-red-600" : "text-stone-700"}`}>
            {String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}
          </span>
        </div>
      </div>
      <p className="text-xs text-stone-400">QR expires in</p>
    </div>
  );
}

export default function QRPayment({ amount, occasion, userEmail, userName, onSuccess, onClose }: QRPaymentProps) {
  const { t } = useLanguage();
  const [step, setStep] = useState<PaymentStep>("init");
  const [paymentData, setPaymentData] = useState<PaymentData | null>(null);
  const [loading, setLoading] = useState(false);
  const [upiRef, setUpiRef] = useState("");
  const [transactionResult, setTransactionResult] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopPolling = () => {
    if (pollRef.current) clearInterval(pollRef.current);
  };

  const handleExpired = useCallback(() => {
    stopPolling();
    setStep("expired");
  }, []);

  // Initiate payment
  const initiatePayment = async () => {
    setLoading(true);
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userEmail, userName, amount, occasion }),
    });
    if (res.ok) {
      const data = await res.json();
      setPaymentData(data);
      setStep("qr");
    } else {
      setStep("failed");
    }
    setLoading(false);
  };

  // Poll for status
  useEffect(() => {
    if (step === "confirming" && paymentData) {
      pollRef.current = setInterval(async () => {
        const res = await fetch(`/api/payments?orderId=${paymentData.orderId}`);
        const data = await res.json();
        if (data.status === "success") {
          stopPolling();
          setTransactionResult(data.transaction);
          setStep("success");
          onSuccess?.(paymentData.orderId);
        } else if (data.status === "expired") {
          stopPolling();
          setStep("expired");
        }
      }, 3000);
    }
    return stopPolling;
  }, [step, paymentData]);

  const handleConfirmPaid = async () => {
    if (!paymentData) return;
    setStep("confirming");
    setLoading(true);
    const res = await fetch("/api/payments/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderId: paymentData.orderId, upiRef }),
    });
    const data = await res.json();
    setLoading(false);
    if (data.status === "success") {
      setTransactionResult(data.transaction);
      setStep("success");
      onSuccess?.(paymentData.orderId);
    } else if (data.status === "expired") {
      setStep("expired");
    } else {
      setStep("failed");
    }
  };

  const copyUPI = () => {
    if (paymentData) {
      navigator.clipboard.writeText(paymentData.upiId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadReceipt = () => {
    if (!transactionResult) return;
    const content = `
EUPHORIA — PAYMENT RECEIPT
============================
Transaction ID : ${transactionResult._id}
Order ID       : ${transactionResult.orderId}
UPI Reference  : ${transactionResult.upiRef || "N/A"}
Amount         : ₹${transactionResult.amount}
Occasion       : ${transactionResult.occasion}
Paid By        : ${transactionResult.userName}
Status         : ${transactionResult.status.toUpperCase()}
Date           : ${new Date(transactionResult.updatedAt).toLocaleString("en-IN")}
============================
Thank you for choosing Euphoria!
    `.trim();
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `euphoria-receipt-${transactionResult.orderId}.txt`;
    a.click();
  };

  const qrImageUrl = paymentData ? generateQRDataURL(paymentData.upiString) : null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-[#FFFAF0] rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100">
          <h2 className="font-serif text-lg text-stone-800">
            {step === "success" ? "Payment Complete" : step === "failed" ? "Payment Failed" : step === "expired" ? "QR Expired" : t("Scan to Pay")}
          </h2>
          <button onClick={onClose} className="p-1.5 text-stone-400 hover:text-stone-600 rounded-lg hover:bg-stone-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <AnimatePresence mode="wait">
            {/* INIT */}
            {step === "init" && (
              <motion.div key="init" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center space-y-5">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-100 flex items-center justify-center">
                  <Smartphone className="w-8 h-8 text-amber-600" />
                </div>
                <div>
                  <p className="text-3xl font-serif font-bold text-stone-800">₹{amount.toLocaleString("en-IN")}</p>
                  <p className="text-stone-500 text-sm mt-1">{occasion} Booking</p>
                </div>
                <div className="bg-stone-50 rounded-2xl p-4 text-left space-y-2">
                  <p className="text-xs text-stone-400 font-semibold uppercase tracking-wider">Pay via</p>
                  <div className="grid grid-cols-2 gap-2">
                    {UPI_APPS.map((app) => (
                      <div key={app.name} className="flex items-center gap-2 bg-white rounded-xl px-3 py-2 text-xs text-stone-600 border border-stone-100">
                        <span>{app.icon}</span>{app.name}
                      </div>
                    ))}
                  </div>
                </div>
                <button
                  onClick={initiatePayment}
                  disabled={loading}
                  className="w-full bg-stone-800 text-white py-3.5 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:bg-stone-700 transition-colors disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronRight className="w-5 h-5" />}
                  {t("Pay Now")} — ₹{amount.toLocaleString("en-IN")}
                </button>
              </motion.div>
            )}

            {/* QR */}
            {step === "qr" && paymentData && (
              <motion.div key="qr" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-2xl font-bold text-stone-800">₹{paymentData.amount.toLocaleString("en-IN")}</p>
                    <p className="text-stone-400 text-xs mt-0.5">{paymentData.orderId}</p>
                  </div>
                  <CountdownTimer expiry={paymentData.qrExpiry} onExpired={handleExpired} />
                </div>

                {/* QR Code */}
                <div className="flex justify-center">
                  <div className="bg-white p-3 rounded-2xl shadow-sm border border-stone-100">
                    <img src={qrImageUrl!} alt="UPI QR Code" className="w-44 h-44 rounded-xl" />
                  </div>
                </div>

                {/* UPI ID */}
                <div className="bg-stone-50 rounded-xl flex items-center justify-between px-4 py-3">
                  <div>
                    <p className="text-[10px] text-stone-400 uppercase tracking-wider font-semibold">UPI ID</p>
                    <p className="text-sm font-mono text-stone-700">{paymentData.upiId}</p>
                  </div>
                  <button onClick={copyUPI} className="text-xs text-amber-600 font-semibold flex items-center gap-1">
                    <Copy className="w-3.5 h-3.5" />
                    {copied ? "Copied!" : "Copy"}
                  </button>
                </div>

                {/* UPI Ref input */}
                <div>
                  <p className="text-xs text-stone-500 mb-1.5">Enter UPI Reference (optional)</p>
                  <input
                    value={upiRef}
                    onChange={(e) => setUpiRef(e.target.value)}
                    placeholder="e.g. 408123456789"
                    className="w-full border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-400"
                  />
                </div>

                <button
                  onClick={handleConfirmPaid}
                  disabled={loading}
                  className="w-full bg-emerald-600 text-white py-3.5 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:bg-emerald-700 transition-colors disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                  I've Paid
                </button>
              </motion.div>
            )}

            {/* CONFIRMING */}
            {step === "confirming" && (
              <motion.div key="confirming" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center py-8 space-y-4">
                <Loader2 className="w-12 h-12 mx-auto text-amber-500 animate-spin" />
                <p className="font-semibold text-stone-700">Verifying Payment...</p>
                <p className="text-stone-400 text-sm">Please wait while we confirm your payment</p>
              </motion.div>
            )}

            {/* SUCCESS */}
            {step === "success" && (
              <motion.div key="success" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center space-y-5 py-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 12, delay: 0.1 }}
                  className="w-20 h-20 mx-auto rounded-full bg-emerald-100 flex items-center justify-center"
                >
                  <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                </motion.div>
                <div>
                  <p className="text-2xl font-bold text-stone-800">₹{paymentData?.amount.toLocaleString("en-IN")}</p>
                  <p className="text-emerald-600 font-semibold mt-1">{t("Payment Successful")}</p>
                </div>
                {transactionResult && (
                  <div className="bg-stone-50 rounded-2xl p-4 text-left space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-stone-400">Order ID</span>
                      <span className="font-mono text-xs text-stone-700">{transactionResult.orderId}</span>
                    </div>
                    {transactionResult.upiRef && (
                      <div className="flex justify-between">
                        <span className="text-stone-400">UPI Ref</span>
                        <span className="font-mono text-xs text-stone-700">{transactionResult.upiRef}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-stone-400">Date</span>
                      <span className="text-stone-700 text-xs">{new Date(transactionResult.updatedAt).toLocaleString("en-IN")}</span>
                    </div>
                  </div>
                )}
                <div className="flex gap-2">
                  <button
                    onClick={downloadReceipt}
                    className="flex-1 flex items-center justify-center gap-2 border border-stone-200 py-2.5 rounded-xl text-sm text-stone-700 hover:bg-stone-50 transition-colors"
                  >
                    <Download className="w-4 h-4" /> {t("Download Receipt")}
                  </button>
                  <button
                    onClick={onClose}
                    className="flex-1 bg-stone-800 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-stone-700 transition-colors"
                  >
                    Done
                  </button>
                </div>
              </motion.div>
            )}

            {/* FAILED */}
            {step === "failed" && (
              <motion.div key="failed" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center space-y-5 py-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-red-100 flex items-center justify-center">
                  <AlertCircle className="w-10 h-10 text-red-500" />
                </div>
                <p className="font-semibold text-stone-800">{t("Payment Failed")}</p>
                <p className="text-stone-400 text-sm">Something went wrong. Please try again.</p>
                <button
                  onClick={() => { setStep("init"); setPaymentData(null); setUpiRef(""); }}
                  className="w-full flex items-center justify-center gap-2 bg-stone-800 text-white py-3.5 rounded-2xl font-semibold hover:bg-stone-700 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" /> {t("Retry Payment")}
                </button>
              </motion.div>
            )}

            {/* EXPIRED */}
            {step === "expired" && (
              <motion.div key="expired" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center space-y-5 py-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-amber-100 flex items-center justify-center">
                  <Clock className="w-10 h-10 text-amber-500" />
                </div>
                <p className="font-semibold text-stone-800">QR Code Expired</p>
                <p className="text-stone-400 text-sm">The payment QR code has expired. Generate a new one.</p>
                <button
                  onClick={() => { setStep("init"); setPaymentData(null); setUpiRef(""); }}
                  className="w-full flex items-center justify-center gap-2 bg-stone-800 text-white py-3.5 rounded-2xl font-semibold hover:bg-stone-700 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" /> Generate New QR
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  );
}
