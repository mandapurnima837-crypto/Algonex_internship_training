"use client";

import { useState, useRef, useEffect } from "react";
import { Globe } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage, LANGUAGE_OPTIONS, Language } from "@/context/LanguageContext";

interface LanguageSelectorProps {
  variant?: "navbar" | "mobile" | "settings";
}

export default function LanguageSelector({ variant = "navbar" }: LanguageSelectorProps) {
  const { language, setLanguage } = useLanguage();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const current = LANGUAGE_OPTIONS.find((l) => l.code === language) || LANGUAGE_OPTIONS[0];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (code: Language) => {
    setLanguage(code);
    setOpen(false);
  };

  if (variant === "mobile") {
    return (
      <div className="border-b border-stone-200/50 pb-4">
        <p className="text-xs text-stone-400 uppercase tracking-widest mb-3 font-medium">Language</p>
        <div className="grid grid-cols-2 gap-2">
          {LANGUAGE_OPTIONS.map((opt) => (
            <button
              key={opt.code}
              onClick={() => handleSelect(opt.code)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all ${
                language === opt.code
                  ? "bg-amber-100 text-amber-800 font-semibold border border-amber-200"
                  : "bg-stone-50 text-stone-600 hover:bg-stone-100"
              }`}
            >
              <span className="text-base">{opt.flag}</span>
              <span>{opt.nativeName}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (variant === "settings") {
    return (
      <div className="space-y-3">
        {LANGUAGE_OPTIONS.map((opt) => (
          <button
            key={opt.code}
            onClick={() => handleSelect(opt.code)}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${
              language === opt.code
                ? "border-amber-300 bg-amber-50 text-amber-800"
                : "border-stone-200 bg-white text-stone-700 hover:border-stone-300"
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-xl">{opt.flag}</span>
              <div className="text-left">
                <p className="font-medium text-sm">{opt.name}</p>
                <p className="text-xs text-stone-400">{opt.nativeName}</p>
              </div>
            </div>
            {language === opt.code && (
              <div className="w-2 h-2 rounded-full bg-amber-500" />
            )}
          </button>
        ))}
      </div>
    );
  }

  // Default: navbar dropdown
  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((p) => !p)}
        className="flex items-center gap-1.5 text-sm text-stone-600 hover:text-stone-900 transition-colors px-2 py-1.5 rounded-lg hover:bg-stone-100"
        aria-label="Select language"
      >
        <Globe className="w-4 h-4" />
        <span className="text-base leading-none">{current.flag}</span>
        <span className="hidden lg:inline font-medium">{current.code}</span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.96 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 top-full mt-2 w-52 bg-white rounded-2xl shadow-xl border border-stone-100 overflow-hidden z-[100]"
          >
            <div className="px-3 pt-3 pb-1">
              <p className="text-[10px] uppercase tracking-widest text-stone-400 font-semibold px-1">Select Language</p>
            </div>
            {LANGUAGE_OPTIONS.map((opt) => (
              <button
                key={opt.code}
                onClick={() => handleSelect(opt.code)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                  language === opt.code
                    ? "bg-amber-50 text-amber-800 font-semibold"
                    : "text-stone-700 hover:bg-stone-50"
                }`}
              >
                <span className="text-base">{opt.flag}</span>
                <div className="flex-1 text-left">
                  <span className="font-medium">{opt.name}</span>
                  <span className="ml-1.5 text-stone-400 text-xs">{opt.nativeName}</span>
                </div>
                {language === opt.code && (
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500 flex-shrink-0" />
                )}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
