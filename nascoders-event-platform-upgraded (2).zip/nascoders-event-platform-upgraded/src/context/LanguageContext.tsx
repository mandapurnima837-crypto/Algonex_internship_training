"use client";
import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type Language = "EN" | "HI" | "TE" | "TA" | "KN";

export const LANGUAGE_OPTIONS: { code: Language; name: string; nativeName: string; flag: string }[] = [
  { code: "EN", name: "English",  nativeName: "English",   flag: "🇬🇧" },
  { code: "HI", name: "Hindi",    nativeName: "हिंदी",      flag: "🇮🇳" },
  { code: "TE", name: "Telugu",   nativeName: "తెలుగు",     flag: "🇮🇳" },
  { code: "TA", name: "Tamil",    nativeName: "தமிழ்",      flag: "🇮🇳" },
  { code: "KN", name: "Kannada",  nativeName: "ಕನ್ನಡ",      flag: "🇮🇳" },
];

type TranslationMap = { [key: string]: string };
type Translations = { [key in Language]: TranslationMap };

const translations: Translations = {
  EN: {
    "Discover the Magic": "Discover the Magic",
    "Explore Surprises": "Explore Surprises",
    "Book Now": "Book Now",
    "View Details": "View Details",
    "Reveal Quote": "Reveal Quote",
    "Join Euphoria": "Join Euphoria",
    "Your emotional memory space": "Your emotional memory space",
    "FULL NAME": "FULL NAME",
    "MOBILE NUMBER": "MOBILE NUMBER",
    "Continue": "Continue",
    "Login": "Login",
    "Sign up": "Sign up",
    "Dashboard": "Dashboard",
    "Home": "Home",
    "About Us": "About Us",
    "Contact": "Contact",
    "Plan Unforgettable": "Plan Unforgettable",
    "Celebrations.": "Celebrations.",
    "Crafted with Love": "Crafted with Love",
    "Curated Details": "Curated Details",
    "Meet Our Team": "Meet Our Team",
    "Logout": "Logout",
    "Budget Planner": "Budget Planner",
    "Interactive Budget Planner": "Interactive Budget Planner",
    "Marriage": "Marriage",
    "Grand wedding celebrations": "Grand wedding celebrations",
    "Two hearts, one love, a lifetime of beautiful promises. Celebrating the beginning of your forever.": "Two hearts, one love, a lifetime of beautiful promises. Celebrating the beginning of your forever.",
    "Rate Our App": "Rate Our App",
    "Reviews": "Reviews",
    "Submit Review": "Submit Review",
    "Write a review": "Write a review",
    "Your review": "Your review",
    "Edit": "Edit",
    "Delete": "Delete",
    "Helpful": "Helpful",
    "Filter by": "Filter by",
    "All Stars": "All Stars",
    "Verified User": "Verified User",
    "No reviews yet": "No reviews yet",
    "Be the first to review": "Be the first to review",
    "Pay Now": "Pay Now",
    "Scan to Pay": "Scan to Pay",
    "Payment Successful": "Payment Successful",
    "Payment Failed": "Payment Failed",
    "QR Expires in": "QR Expires in",
    "Transaction ID": "Transaction ID",
    "Download Receipt": "Download Receipt",
    "Retry Payment": "Retry Payment",
    "Select Language": "Select Language",
    "Settings": "Settings",
    "Profile": "Profile",
  },
  HI: {
    "Discover the Magic": "जादू की खोज करें",
    "Explore Surprises": "आश्चर्य का अन्वेषण करें",
    "Book Now": "अभी बुक करें",
    "View Details": "विवरण देखें",
    "Reveal Quote": "उद्धरण देखें",
    "Join Euphoria": "यूफोरिया से जुड़ें",
    "Your emotional memory space": "आपका भावनात्मक स्मृति स्थान",
    "FULL NAME": "पूरा नाम",
    "MOBILE NUMBER": "मोबाइल नंबर",
    "Continue": "जारी रखें",
    "Login": "लॉग इन",
    "Sign up": "साइन अप",
    "Dashboard": "डैशबोर्ड",
    "Home": "होम",
    "About Us": "हमारे बारे में",
    "Contact": "संपर्क करें",
    "Plan Unforgettable": "अविस्मरणीय योजना बनाएं",
    "Celebrations.": "समारोह।",
    "Crafted with Love": "प्यार से बनाया गया",
    "Curated Details": "क्यूरेटेड विवरण",
    "Meet Our Team": "हमारी टीम से मिलें",
    "Logout": "लॉग आउट",
    "Budget Planner": "बजट योजनाकार",
    "Interactive Budget Planner": "इंटरैक्टिव बजट योजनाकार",
    "Marriage": "विवाह",
    "Grand wedding celebrations": "भव्य विवाह समारोह",
    "Two hearts, one love, a lifetime of beautiful promises. Celebrating the beginning of your forever.": "दो दिल, एक प्यार, जीवनभर के खूबसूरत वादे।",
    "Rate Our App": "हमारे ऐप को रेट करें",
    "Reviews": "समीक्षाएं",
    "Submit Review": "समीक्षा सबमिट करें",
    "Write a review": "समीक्षा लिखें",
    "Your review": "आपकी समीक्षा",
    "Edit": "संपादित करें",
    "Delete": "हटाएं",
    "Helpful": "उपयोगी",
    "Filter by": "फ़िल्टर करें",
    "All Stars": "सभी रेटिंग",
    "Verified User": "सत्यापित उपयोगकर्ता",
    "No reviews yet": "अभी तक कोई समीक्षा नहीं",
    "Be the first to review": "पहली समीक्षा करें",
    "Pay Now": "अभी भुगतान करें",
    "Scan to Pay": "स्कैन करें और भुगतान करें",
    "Payment Successful": "भुगतान सफल",
    "Payment Failed": "भुगतान विफल",
    "QR Expires in": "QR समाप्त होगा",
    "Transaction ID": "लेनदेन आईडी",
    "Download Receipt": "रसीद डाउनलोड करें",
    "Retry Payment": "पुनः प्रयास करें",
    "Select Language": "भाषा चुनें",
    "Settings": "सेटिंग्स",
    "Profile": "प्रोफ़ाइल",
  },
  TE: {
    "Discover the Magic": "మ్యాజిక్ కనుగొనండి",
    "Explore Surprises": "ఆశ్చర్యాలను అన్వేషించండి",
    "Book Now": "ఇప్పుడే బుక్ చేయండి",
    "View Details": "వివరాలు చూడండి",
    "Reveal Quote": "కోట్ చూడండి",
    "Join Euphoria": "యుఫోరియాలో చేరండి",
    "Your emotional memory space": "మీ భావోద్వేగ జ్ఞాపకాల ప్రదేశం",
    "FULL NAME": "పూర్తి పేరు",
    "MOBILE NUMBER": "మొబైల్ నంబర్",
    "Continue": "కొనసాగించు",
    "Login": "లాగిన్",
    "Sign up": "సైన్ అప్",
    "Dashboard": "డాష్‌బోర్డ్",
    "Home": "హోమ్",
    "About Us": "మా గురించి",
    "Contact": "సంప్రదించండి",
    "Plan Unforgettable": "మరపురాని ప్లాన్ చేయండి",
    "Celebrations.": "వేడుకలు.",
    "Crafted with Love": "ప్రేమతో రూపొందించబడింది",
    "Curated Details": "క్యూరేటెడ్ వివరాలు",
    "Meet Our Team": "మా బృందాన్ని కలవండి",
    "Logout": "లాగ్అవుట్",
    "Budget Planner": "బడ్జెట్ ప్లానర్",
    "Interactive Budget Planner": "ఇంటరాక్టివ్ బడ్జెట్ ప్లానర్",
    "Marriage": "వివాహం",
    "Grand wedding celebrations": "భవ్య వివాహ వేడుకలు",
    "Two hearts, one love, a lifetime of beautiful promises. Celebrating the beginning of your forever.": "రెండు హృదయాలు, ఒక ప్రేమ, జీవితకాలం అందమైన వాగ్దానాలు.",
    "Rate Our App": "మా యాప్‌ని రేట్ చేయండి",
    "Reviews": "సమీక్షలు",
    "Submit Review": "సమీక్ష సమర్పించండి",
    "Write a review": "సమీక్ష రాయండి",
    "Your review": "మీ సమీక్ష",
    "Edit": "సవరించు",
    "Delete": "తొలగించు",
    "Helpful": "సహాయకర",
    "Filter by": "వడపోత",
    "All Stars": "అన్ని రేటింగ్‌లు",
    "Verified User": "ధృవీకరించబడిన వినియోగదారు",
    "No reviews yet": "ఇంకా సమీక్షలు లేవు",
    "Be the first to review": "మొదటి సమీక్షకుడిగా ఉండండి",
    "Pay Now": "ఇప్పుడు చెల్లించండి",
    "Scan to Pay": "స్కాన్ చేసి చెల్లించండి",
    "Payment Successful": "చెల్లింపు విజయవంతమైంది",
    "Payment Failed": "చెల్లింపు విఫలమైంది",
    "QR Expires in": "QR గడువు తీరుతుంది",
    "Transaction ID": "లావాదేవీ ID",
    "Download Receipt": "రసీదు డౌన్‌లోడ్ చేయండి",
    "Retry Payment": "మళ్ళీ ప్రయత్నించండి",
    "Select Language": "భాష ఎంచుకోండి",
    "Settings": "సెట్టింగ్‌లు",
    "Profile": "ప్రొఫైల్",
  },
  TA: {
    "Discover the Magic": "மேஜிக்கை கண்டறியுங்கள்",
    "Explore Surprises": "ஆச்சரியங்களை ஆராயுங்கள்",
    "Book Now": "இப்போது பதிவு செய்",
    "View Details": "விவரங்களை பார்க்க",
    "Reveal Quote": "மேற்கோளைக் காண்க",
    "Join Euphoria": "யூபோரியாவில் சேரவும்",
    "Your emotional memory space": "உங்கள் உணர்ச்சிபூர்வமான நினைவக இடம்",
    "FULL NAME": "முழு பெயர்",
    "MOBILE NUMBER": "மொபைல் எண்",
    "Continue": "தொடரவும்",
    "Login": "உள்நுழைய",
    "Sign up": "பதிவு செய்ய",
    "Dashboard": "டாஷ்போர்டு",
    "Home": "முகப்பு",
    "About Us": "எங்களை பற்றி",
    "Contact": "தொடர்பு கொள்ள",
    "Plan Unforgettable": "மறக்க முடியாத திட்டமிடுங்கள்",
    "Celebrations.": "கொண்டாட்டங்கள்.",
    "Crafted with Love": "காதலுடன் வடிவமைக்கப்பட்டது",
    "Curated Details": "தொகுக்கப்பட்ட விவரங்கள்",
    "Meet Our Team": "எங்கள் குழுவை சந்திக்கவும்",
    "Logout": "வெளியேறு",
    "Budget Planner": "பட்ஜெட் திட்டமிடுபவர்",
    "Interactive Budget Planner": "ஊடாடும் பட்ஜெட் திட்டமிடுபவர்",
    "Marriage": "திருமணம்",
    "Grand wedding celebrations": "பிரம்மாண்ட திருமண கொண்டாட்டங்கள்",
    "Two hearts, one love, a lifetime of beautiful promises. Celebrating the beginning of your forever.": "இரு இதயங்கள், ஒரு காதல், வாழ்நாள் முழுவதும் அழகான வாக்குறுதிகள்.",
    "Rate Our App": "எங்கள் செயலியை மதிப்பிடுங்கள்",
    "Reviews": "மதிப்புரைகள்",
    "Submit Review": "மதிப்புரை சமர்பிக்கவும்",
    "Write a review": "மதிப்புரை எழுதுங்கள்",
    "Your review": "உங்கள் மதிப்புரை",
    "Edit": "திருத்தவும்",
    "Delete": "நீக்கவும்",
    "Helpful": "பயனுள்ளது",
    "Filter by": "வடிகட்டு",
    "All Stars": "அனைத்து மதிப்பீடுகள்",
    "Verified User": "சரிபார்க்கப்பட்ட பயனர்",
    "No reviews yet": "இன்னும் மதிப்புரைகள் இல்லை",
    "Be the first to review": "முதலில் மதிப்பிடுங்கள்",
    "Pay Now": "இப்போது பணம் செலுத்துங்கள்",
    "Scan to Pay": "ஸ்கேன் செய்து பணம் செலுத்துங்கள்",
    "Payment Successful": "கட்டணம் வெற்றிகரமாக செலுத்தப்பட்டது",
    "Payment Failed": "கட்டணம் தோல்வியடைந்தது",
    "QR Expires in": "QR காலாவதியாகும்",
    "Transaction ID": "பரிவர்த்தனை ID",
    "Download Receipt": "ரசீதை பதிவிறக்கவும்",
    "Retry Payment": "மீண்டும் முயற்சிக்கவும்",
    "Select Language": "மொழியை தேர்ந்தெடுக்கவும்",
    "Settings": "அமைப்புகள்",
    "Profile": "சுயவிவரம்",
  },
  KN: {
    "Discover the Magic": "ಮ್ಯಾಜಿಕ್ ಅನ್ವೇಷಿಸಿ",
    "Explore Surprises": "ಆಶ್ಚರ್ಯಗಳನ್ನು ಅನ್ವೇಷಿಸಿ",
    "Book Now": "ಈಗ ಬುಕ್ ಮಾಡಿ",
    "View Details": "ವಿವರಗಳನ್ನು ವೀಕ್ಷಿಸಿ",
    "Reveal Quote": "ಉಲ್ಲೇಖವನ್ನು ವೀಕ್ಷಿಸಿ",
    "Join Euphoria": "ಯುಫೋರಿಯಾ ಸೇರಿ",
    "Your emotional memory space": "ನಿಮ್ಮ ಭಾವನಾತ್ಮಕ ಸ್ಮರಣೆ ಸ್ಥಳ",
    "FULL NAME": "ಪೂರ್ಣ ಹೆಸರು",
    "MOBILE NUMBER": "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
    "Continue": "ಮುಂದುವರಿಸಿ",
    "Login": "ಲಾಗಿನ್",
    "Sign up": "ಸೈನ್ ಅಪ್",
    "Dashboard": "ಡ್ಯಾಶ್ಬೋರ್ಡ್",
    "Home": "ಮುಖಪುಟ",
    "About Us": "ನಮ್ಮ ಬಗ್ಗೆ",
    "Contact": "ಸಂಪರ್ಕಿಸಿ",
    "Plan Unforgettable": "ಮರೆಯಲಾಗದ ಯೋಜನೆ ಮಾಡಿ",
    "Celebrations.": "ಆಚರಣೆಗಳು.",
    "Crafted with Love": "ಪ್ರೀತಿಯಿಂದ ರಚಿಸಲಾಗಿದೆ",
    "Curated Details": "ಕ್ಯುರೇಟೆಡ್ ವಿವರಗಳು",
    "Meet Our Team": "ನಮ್ಮ ತಂಡವನ್ನು ಭೇಟಿ ಮಾಡಿ",
    "Logout": "ಲಾಗ್ಔಟ್",
    "Budget Planner": "ಬಜೆಟ್ ಪ್ಲಾನರ್",
    "Interactive Budget Planner": "ಸಂವಾದಾತ್ಮಕ ಬಜೆಟ್ ಪ್ಲಾನರ್",
    "Marriage": "ವಿವಾಹ",
    "Grand wedding celebrations": "ಭವ್ಯ ವಿವಾಹ ಆಚರಣೆಗಳು",
    "Two hearts, one love, a lifetime of beautiful promises. Celebrating the beginning of your forever.": "ಎರಡು ಹೃದಯಗಳು, ಒಂದು ಪ್ರೀತಿ, ಜೀವಮಾನದ ಸುಂದರ ಭರವಸೆಗಳು.",
    "Rate Our App": "ನಮ್ಮ ಆ್ಯಪ್ ಅನ್ನು ರೇಟ್ ಮಾಡಿ",
    "Reviews": "ವಿಮರ್ಶೆಗಳು",
    "Submit Review": "ವಿಮರ್ಶೆ ಸಲ್ಲಿಸಿ",
    "Write a review": "ವಿಮರ್ಶೆ ಬರೆಯಿರಿ",
    "Your review": "ನಿಮ್ಮ ವಿಮರ್ಶೆ",
    "Edit": "ಸಂಪಾದಿಸಿ",
    "Delete": "ಅಳಿಸಿ",
    "Helpful": "ಸಹಾಯಕ",
    "Filter by": "ಫಿಲ್ಟರ್ ಮಾಡಿ",
    "All Stars": "ಎಲ್ಲಾ ರೇಟಿಂಗ್‌ಗಳು",
    "Verified User": "ಪರಿಶೀಲಿಸಲಾದ ಬಳಕೆದಾರ",
    "No reviews yet": "ಇನ್ನೂ ವಿಮರ್ಶೆಗಳಿಲ್ಲ",
    "Be the first to review": "ಮೊದಲ ವಿಮರ್ಶಕರಾಗಿರಿ",
    "Pay Now": "ಈಗ ಪಾವತಿಸಿ",
    "Scan to Pay": "ಸ್ಕ್ಯಾನ್ ಮಾಡಿ ಮತ್ತು ಪಾವತಿಸಿ",
    "Payment Successful": "ಪಾವತಿ ಯಶಸ್ವಿ",
    "Payment Failed": "ಪಾವತಿ ವಿಫಲ",
    "QR Expires in": "QR ಮುಕ್ತಾಯ",
    "Transaction ID": "ವಹಿವಾಟು ID",
    "Download Receipt": "ರಸೀದಿ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ",
    "Retry Payment": "ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ",
    "Select Language": "ಭಾಷೆ ಆಯ್ಕೆ ಮಾಡಿ",
    "Settings": "ಸೆಟ್ಟಿಂಗ್‌ಗಳು",
    "Profile": "ಪ್ರೊಫೈಲ್",
  },
};

// Detect browser language and map to supported Language
function detectBrowserLanguage(): Language {
  if (typeof window === "undefined") return "EN";
  const browserLang = navigator.language.split("-")[0].toUpperCase();
  const map: Record<string, Language> = { HI: "HI", TE: "TE", TA: "TA", KN: "KN" };
  return map[browserLang] || "EN";
}

interface LanguageContextProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextProps | undefined>(undefined);

const STORAGE_KEY = "euphoria_language";

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("EN");
  const [mounted, setMounted] = useState(false);

  // On mount: load from localStorage or detect browser language
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY) as Language | null;
    const supported: Language[] = ["EN", "HI", "TE", "TA", "KN"];
    if (stored && supported.includes(stored)) {
      setLanguageState(stored);
    } else {
      const detected = detectBrowserLanguage();
      setLanguageState(detected);
      localStorage.setItem(STORAGE_KEY, detected);
    }
    setMounted(true);
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEY, lang);
    // If user is logged in, persist to profile too
    const session = localStorage.getItem("euphoria_session");
    if (session) {
      try {
        const user = JSON.parse(session);
        fetch("/api/user/language", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: user.email, language: lang }),
        }).catch(() => {}); // silent fail if API not ready
      } catch {}
    }
  };

  const t = (key: string): string => {
    if (!mounted) return key;
    return translations[language]?.[key] ?? translations["EN"]?.[key] ?? key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within a LanguageProvider");
  return context;
}
