import mongoose, { Schema, Document } from 'mongoose';

export interface ITransaction extends Document {
  orderId: string;
  userEmail: string;
  userName: string;
  amount: number;
  occasion: string;
  upiId: string;
  upiRef?: string;
  status: 'pending' | 'success' | 'failed' | 'expired';
  qrExpiry: Date;
  createdAt: Date;
  updatedAt: Date;
}

const TransactionSchema: Schema = new Schema(
  {
    orderId:   { type: String, required: true, unique: true },
    userEmail: { type: String, required: true },
    userName:  { type: String, required: true },
    amount:    { type: Number, required: true },
    occasion:  { type: String, required: true },
    upiId:     { type: String, required: true },
    upiRef:    { type: String },
    status:    { type: String, enum: ['pending', 'success', 'failed', 'expired'], default: 'pending' },
    qrExpiry:  { type: Date, required: true },
  },
  { timestamps: true }
);

export default mongoose.models.Transaction || mongoose.model<ITransaction>('Transaction', TransactionSchema);
