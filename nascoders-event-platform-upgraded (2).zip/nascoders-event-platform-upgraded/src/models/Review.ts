import mongoose, { Schema, Document } from 'mongoose';

export interface IReview extends Document {
  userEmail: string;
  userName: string;
  rating: number;        // 1–5
  title: string;
  body: string;
  helpfulVotes: string[]; // array of userEmails who found helpful
  isPinned: boolean;
  isHidden: boolean;      // admin moderation
  isVerified: boolean;    // user has at least one booking
  createdAt: Date;
  updatedAt: Date;
}

const ReviewSchema: Schema = new Schema(
  {
    userEmail:    { type: String, required: true, unique: true }, // one review per user
    userName:     { type: String, required: true },
    rating:       { type: Number, required: true, min: 1, max: 5 },
    title:        { type: String, required: true, maxlength: 100 },
    body:         { type: String, required: true, maxlength: 1000 },
    helpfulVotes: { type: [String], default: [] },
    isPinned:     { type: Boolean, default: false },
    isHidden:     { type: Boolean, default: false },
    isVerified:   { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default mongoose.models.Review || mongoose.model<IReview>('Review', ReviewSchema);
