/* eslint-disable */
"use client";

import { useEffect, useState } from "react";
import ReviewSystem from "@/components/ReviewSystem";

export default function ReviewsPage() {
  const [user, setUser] = useState<{ name: string; email: string; role?: string } | null>(null);

  useEffect(() => {
    const session = localStorage.getItem("euphoria_session");
    if (session) setUser(JSON.parse(session));
  }, []);

  return (
    <div className="min-h-screen bg-[#FFFAF0]">
      <ReviewSystem
        currentUserEmail={user?.email}
        currentUserName={user?.name}
        isAdmin={user?.role === "admin"}
      />
    </div>
  );
}
