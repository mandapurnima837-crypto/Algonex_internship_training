/* eslint-disable */
"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Clock, AlertCircle, XCircle, Download, ArrowLeft } from "lucide-react";
import Link from "next/link";

interface Transaction {
  _id: string;
  orderId: string;
  amount: number;
  occasion: string;
  status: "pending" | "success" | "failed" | "expired";
  upiRef?: string;
  createdAt: string;
}

const statusConfig = {
  success: { icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50", label: "Paid" },
  pending: { icon: Clock, color: "text-amber-600", bg: "bg-amber-50", label: "Pending" },
  failed:  { icon: AlertCircle, color: "text-red-600", bg: "bg-red-50", label: "Failed" },
  expired: { icon: XCircle, color: "text-stone-400", bg: "bg-stone-50", label: "Expired" },
};

export default function TransactionsPage() {
  const [user, setUser] = useState<{ name: string; email: string; role?: string } | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = localStorage.getItem("euphoria_session");
    if (session) {
      const u = JSON.parse(session);
      setUser(u);
      fetch(`/api/payments/history?email=${u.email}&role=${u.role || "user"}`)
        .then((r) => r.json())
        .then((d) => { setTransactions(d.transactions || []); setLoading(false); });
    } else {
      setLoading(false);
    }
  }, []);

  const downloadReceipt = (tx: Transaction) => {
    const content = `
EUPHORIA — PAYMENT RECEIPT
============================
Transaction ID : ${tx._id}
Order ID       : ${tx.orderId}
UPI Reference  : ${tx.upiRef || "N/A"}
Amount         : ₹${tx.amount}
Occasion       : ${tx.occasion}
Status         : ${tx.status.toUpperCase()}
Date           : ${new Date(tx.createdAt).toLocaleString("en-IN")}
============================
Thank you for choosing Euphoria!
    `.trim();
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `euphoria-receipt-${tx.orderId}.txt`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-[#FFFAF0] px-6 py-10 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Link href="/profile" className="p-2 rounded-xl hover:bg-stone-100 text-stone-500 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="font-serif text-2xl text-stone-800">Transaction History</h1>
          <p className="text-stone-400 text-sm">All your payment records</p>
        </div>
      </div>

      {!user ? (
        <div className="text-center py-20 text-stone-400">
          <p>Please <Link href="/login" className="text-amber-600 underline">login</Link> to view transactions.</p>
        </div>
      ) : loading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => (
            <div key={i} className="bg-white rounded-2xl p-5 animate-pulse h-20" />
          ))}
        </div>
      ) : transactions.length === 0 ? (
        <div className="text-center py-20 text-stone-400">
          <Clock className="w-12 h-12 mx-auto mb-3 text-stone-200" />
          <p>No transactions yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {transactions.map((tx, i) => {
            const cfg = statusConfig[tx.status];
            const Icon = cfg.icon;
            return (
              <motion.div
                key={tx._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="bg-white rounded-2xl p-5 border border-stone-100 flex items-center justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-xl ${cfg.bg} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${cfg.color}`} />
                  </div>
                  <div>
                    <p className="font-semibold text-stone-800 text-sm">{tx.occasion}</p>
                    <p className="text-xs text-stone-400 font-mono">{tx.orderId}</p>
                    <p className="text-xs text-stone-400">{new Date(tx.createdAt).toLocaleString("en-IN")}</p>
                  </div>
                </div>
                <div className="text-right flex items-center gap-3">
                  <div>
                    <p className="font-bold text-stone-800">₹{tx.amount.toLocaleString("en-IN")}</p>
                    <span className={`text-xs font-semibold ${cfg.color}`}>{cfg.label}</span>
                  </div>
                  {tx.status === "success" && (
                    <button onClick={() => downloadReceipt(tx)} className="p-2 text-stone-400 hover:text-stone-700 transition-colors">
                      <Download className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
