import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import Transaction from '@/models/Transaction';
import crypto from 'crypto';

const MERCHANT_UPI = process.env.MERCHANT_UPI_ID || 'euphoria@upi';
const QR_VALIDITY_MINUTES = 10;

// POST — initiate payment, create transaction & return UPI string
export async function POST(req: Request) {
  await connectToDatabase();
  const { userEmail, userName, amount, occasion } = await req.json();

  if (!userEmail || !amount || !occasion) {
    return NextResponse.json({ message: 'Missing fields' }, { status: 400 });
  }

  const orderId = `EUR-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  const qrExpiry = new Date(Date.now() + QR_VALIDITY_MINUTES * 60 * 1000);

  const transaction = await Transaction.create({
    orderId,
    userEmail,
    userName: userName || 'Guest',
    amount,
    occasion,
    upiId: MERCHANT_UPI,
    qrExpiry,
    status: 'pending',
  });

  // UPI deep link string (standard format)
  const upiString = `upi://pay?pa=${encodeURIComponent(MERCHANT_UPI)}&pn=Euphoria&am=${amount}&cu=INR&tn=${encodeURIComponent(`Euphoria-${occasion}-${orderId}`)}&tr=${orderId}`;

  return NextResponse.json({
    orderId,
    upiString,
    upiId: MERCHANT_UPI,
    amount,
    qrExpiry: qrExpiry.toISOString(),
    transactionId: transaction._id,
  }, { status: 201 });
}

// GET — check payment status
export async function GET(req: Request) {
  await connectToDatabase();
  const { searchParams } = new URL(req.url);
  const orderId = searchParams.get('orderId');
  if (!orderId) return NextResponse.json({ message: 'Missing orderId' }, { status: 400 });

  const transaction = await Transaction.findOne({ orderId }).lean();
  if (!transaction) return NextResponse.json({ message: 'Not found' }, { status: 404 });

  // Auto-expire if QR time has passed
  if ((transaction as any).status === 'pending' && new Date() > new Date((transaction as any).qrExpiry)) {
    await Transaction.findOneAndUpdate({ orderId }, { status: 'expired' });
    return NextResponse.json({ status: 'expired', orderId }, { status: 200 });
  }

  return NextResponse.json({ status: (transaction as any).status, orderId, transaction }, { status: 200 });
}
