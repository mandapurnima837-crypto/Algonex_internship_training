import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import Transaction from '@/models/Transaction';

// POST — user confirms payment (in a real integration, this would be called by payment gateway webhook)
export async function POST(req: Request) {
  await connectToDatabase();
  const { orderId, upiRef } = await req.json();

  if (!orderId) return NextResponse.json({ message: 'Missing orderId' }, { status: 400 });

  const transaction = await Transaction.findOne({ orderId });
  if (!transaction) return NextResponse.json({ message: 'Transaction not found' }, { status: 404 });

  if (transaction.status === 'expired') {
    return NextResponse.json({ message: 'QR code has expired', status: 'expired' }, { status: 400 });
  }
  if (transaction.status === 'success') {
    return NextResponse.json({ message: 'Already paid', status: 'success', transaction }, { status: 200 });
  }

  // Validate QR expiry
  if (new Date() > transaction.qrExpiry) {
    transaction.status = 'expired';
    await transaction.save();
    return NextResponse.json({ message: 'QR code expired', status: 'expired' }, { status: 400 });
  }

  // Mark success (in production: verify upiRef with bank/gateway)
  transaction.status = 'success';
  if (upiRef) transaction.upiRef = upiRef;
  await transaction.save();

  return NextResponse.json({ message: 'Payment verified successfully', status: 'success', transaction }, { status: 200 });
}
