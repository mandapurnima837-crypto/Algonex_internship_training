import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import Transaction from '@/models/Transaction';

export async function GET(req: Request) {
  await connectToDatabase();
  const { searchParams } = new URL(req.url);
  const email = searchParams.get('email');
  const role = searchParams.get('role');

  if (!email) return NextResponse.json({ message: 'Missing email' }, { status: 400 });

  const filter = role === 'admin' ? {} : { userEmail: email };
  const transactions = await Transaction.find(filter).sort({ createdAt: -1 }).lean();

  return NextResponse.json({ transactions }, { status: 200 });
}
