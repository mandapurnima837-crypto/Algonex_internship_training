import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import User from '@/models/User';

export async function POST(req: Request) {
  await connectToDatabase();
  const { email, language } = await req.json();
  if (!email || !language) return NextResponse.json({ message: 'Missing fields' }, { status: 400 });
  await User.findOneAndUpdate({ email }, { preferredLanguage: language });
  return NextResponse.json({ message: 'Language preference saved' }, { status: 200 });
}
