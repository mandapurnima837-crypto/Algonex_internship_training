import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import Review from '@/models/Review';

// POST /api/reviews/helpful — toggle helpful vote
export async function POST(req: Request) {
  await connectToDatabase();
  const { reviewId, voterEmail } = await req.json();
  if (!reviewId || !voterEmail) return NextResponse.json({ message: 'Missing fields' }, { status: 400 });

  const review = await Review.findById(reviewId);
  if (!review) return NextResponse.json({ message: 'Review not found' }, { status: 404 });

  const idx = review.helpfulVotes.indexOf(voterEmail);
  if (idx === -1) {
    review.helpfulVotes.push(voterEmail);
  } else {
    review.helpfulVotes.splice(idx, 1);
  }
  await review.save();

  return NextResponse.json({ helpfulCount: review.helpfulVotes.length }, { status: 200 });
}
