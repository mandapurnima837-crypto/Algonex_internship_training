import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import Review from '@/models/Review';
import Booking from '@/models/Booking';

// GET /api/reviews — fetch all (public)
export async function GET(req: Request) {
  await connectToDatabase();
  const { searchParams } = new URL(req.url);
  const star = searchParams.get('star');
  const sort = searchParams.get('sort') || 'recent'; // recent | helpful | rating
  const page = parseInt(searchParams.get('page') || '1');
  const limit = 10;

  const filter: any = { isHidden: false };
  if (star) filter.rating = parseInt(star);

  let sortOption: any = { isPinned: -1, createdAt: -1 };
  if (sort === 'helpful') sortOption = { isPinned: -1, helpfulVotes: -1, createdAt: -1 };
  if (sort === 'rating')  sortOption = { isPinned: -1, rating: -1, createdAt: -1 };

  const [reviews, total] = await Promise.all([
    Review.find(filter).sort(sortOption).skip((page - 1) * limit).limit(limit).lean(),
    Review.countDocuments(filter),
  ]);

  // Aggregate stats
  const stats = await Review.aggregate([
    { $match: { isHidden: false } },
    {
      $group: {
        _id: null,
        avgRating: { $avg: '$rating' },
        total: { $sum: 1 },
        star5: { $sum: { $cond: [{ $eq: ['$rating', 5] }, 1, 0] } },
        star4: { $sum: { $cond: [{ $eq: ['$rating', 4] }, 1, 0] } },
        star3: { $sum: { $cond: [{ $eq: ['$rating', 3] }, 1, 0] } },
        star2: { $sum: { $cond: [{ $eq: ['$rating', 2] }, 1, 0] } },
        star1: { $sum: { $cond: [{ $eq: ['$rating', 1] }, 1, 0] } },
      },
    },
  ]);

  return NextResponse.json({ reviews, total, page, stats: stats[0] || null }, { status: 200 });
}

// POST /api/reviews — create or update own review
export async function POST(req: Request) {
  await connectToDatabase();
  const body = await req.json();
  const { userEmail, userName, rating, title, body: reviewBody } = body;

  if (!userEmail || !userName || !rating || !title || !reviewBody) {
    return NextResponse.json({ message: 'Missing fields' }, { status: 400 });
  }
  if (rating < 1 || rating > 5) {
    return NextResponse.json({ message: 'Rating must be 1–5' }, { status: 400 });
  }

  // Check if verified (has bookings)
  const bookingCount = await Booking.countDocuments({ userEmail });
  const isVerified = bookingCount > 0;

  const review = await Review.findOneAndUpdate(
    { userEmail },
    { userName, rating, title, body: reviewBody, isVerified },
    { upsert: true, new: true }
  );

  return NextResponse.json({ message: 'Review saved', review }, { status: 201 });
}

// DELETE /api/reviews — delete own review
export async function DELETE(req: Request) {
  await connectToDatabase();
  const { userEmail } = await req.json();
  if (!userEmail) return NextResponse.json({ message: 'Missing email' }, { status: 400 });
  await Review.deleteOne({ userEmail });
  return NextResponse.json({ message: 'Review deleted' }, { status: 200 });
}
