import { NextResponse } from 'next/server';
import connectToDatabase from '@/lib/db';
import Review from '@/models/Review';

// GET — admin: all reviews including hidden
export async function GET() {
  await connectToDatabase();
  const reviews = await Review.find({}).sort({ isPinned: -1, createdAt: -1 }).lean();
  return NextResponse.json({ reviews }, { status: 200 });
}

// PATCH — admin: pin/hide a review
export async function PATCH(req: Request) {
  await connectToDatabase();
  const { reviewId, action } = await req.json(); // action: 'pin' | 'hide' | 'unhide' | 'unpin'
  if (!reviewId || !action) return NextResponse.json({ message: 'Missing fields' }, { status: 400 });

  const update: any = {};
  if (action === 'pin')    update.isPinned = true;
  if (action === 'unpin')  update.isPinned = false;
  if (action === 'hide')   update.isHidden = true;
  if (action === 'unhide') update.isHidden = false;

  const review = await Review.findByIdAndUpdate(reviewId, update, { new: true });
  return NextResponse.json({ review }, { status: 200 });
}

// DELETE — admin force delete any review
export async function DELETE(req: Request) {
  await connectToDatabase();
  const { reviewId } = await req.json();
  await Review.findByIdAndDelete(reviewId);
  return NextResponse.json({ message: 'Deleted' }, { status: 200 });
}
